package com.model2.mvc.service.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.model2.mvc.common.SearchVO;
import com.model2.mvc.common.dao.AbstractDao;
import com.model2.mvc.common.util.DBUtil;
import com.model2.mvc.service.product.vo.ProductVO;
import com.model2.mvc.service.user.vo.UserVO;

public class ProductDAO extends AbstractDao {

	public ProductDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public ProductVO findProduct(int prodNo) {
		System.out.println("PDAO FindProduct start");
		Connection con = DBUtil.getConnection();
		ProductVO productVO = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
	
			con = this.connect();
			
			String sql = "select * from PRODUCT where PROD_NO=?";			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, prodNo);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				productVO = new ProductVO();
				productVO.setProdNo(rs.getInt("prod_no"));
				productVO.setProdName(rs.getString("prod_name"));
				productVO.setProdDetail(rs.getString("prod_detail"));
				productVO.setManuDate(rs.getString("manufacture_day"));
				productVO.setPrice(rs.getInt("price"));
				productVO.setFileName(rs.getString("image_file"));
				productVO.setRegDate(rs.getDate("reg_date"));
				System.out.println(productVO);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			this.close(con, pstmt);
			System.out.println("PDAO FindProduct end");
		}		
		
		return productVO;
	}
	
	public HashMap<String, Object> getProductList(SearchVO searchVO){
		
		System.out.println("PDAO GetProductList start");
		Connection con = DBUtil.getConnection();
		ProductVO productVO = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		HashMap<String,Object> map = new HashMap<String,Object>();
		
		try {
	
			con = this.connect();
			
			String sql = "select * from PRODUCT";
			if (searchVO.getSearchCondition() != null) {
				if (searchVO.getSearchCondition().equals("0")) {
					sql += " where prod_no='" + searchVO.getSearchKeyword()
							+ "'";
				} else if (searchVO.getSearchCondition().equals("1")) {
					sql += " where prod_name='" + searchVO.getSearchKeyword()
							+ "'";
				}
			}
			sql += " order by prod_no";

			pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = pstmt.executeQuery();

			rs.last();
			int total = rs.getRow();			
			System.out.println("�ο��� ��:" + total);
			
			map.put("count", new Integer(total));
			
			rs.absolute(searchVO.getPage() * searchVO.getPageUnit() - searchVO.getPageUnit()+1);
			System.out.println("searchVO.getPage():" + searchVO.getPage());
			System.out.println("searchVO.getPageUnit():" + searchVO.getPageUnit());
			
			List<ProductVO> list = new ArrayList<ProductVO>();
			if (total > 0) {
				for (int i = 0; i < searchVO.getPageUnit(); i++) {
					productVO = new ProductVO();
					productVO.setProdNo(rs.getInt("prod_no"));
					productVO.setProdName(rs.getString("prod_name"));
					productVO.setProdDetail(rs.getString("prod_detail"));
					productVO.setManuDate(rs.getString("manufacture_day"));
					productVO.setPrice(rs.getInt("price"));
					productVO.setFileName(rs.getString("image_file"));
					productVO.setRegDate(rs.getDate("reg_date"));
					System.out.println(productVO);

					list.add(productVO);
					if (!rs.next())
						break;
				}
			}
			System.out.println("list.size() : "+ list.size());
			map.put("list", list);
			System.out.println("map().size() : "+ map.size());
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			this.close(con, pstmt);
			System.out.println("PDAO GetProductList end");
		}
		
		return map;
	}
	
	public void insertProduct(ProductVO productVO) {
		System.out.println("PDAO InsertProduct start");
		Connection con = DBUtil.getConnection();
		PreparedStatement pstmt = null;
		
		try {	
			con = this.connect();
			
			String sql = "insert into PRODUCT values ((seq_product_prod_no.NEXTVAL),?,?,?,?,?,sysdate)";			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, productVO.getProdName());
			pstmt.setString(2, productVO.getProdDetail());
			pstmt.setString(3, productVO.getManuDate());
			pstmt.setInt(4, productVO.getPrice());
			pstmt.setString(5, productVO.getFileName());
			
			int s = pstmt.executeUpdate();
			if(s==1) {
				System.out.println("Insert ����");
			} else {
				System.out.println("SQL Insert ����");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			this.close(con, pstmt);
			System.out.println("PDAO InsertProduct end");
		}
	}
	
	public void updateProduct(ProductVO productVO) {
		System.out.println("PDAO UpdateProduct start");
		Connection con = DBUtil.getConnection();
		PreparedStatement pstmt = null;
		
		try {
	
			con = this.connect();
			
			String sql = "UPDATE PRODUCT\r\n"
					+ "SET\r\n"
					+ "prod_name =?,\r\n"
					+ "prod_detail =?,\r\n"
					+ "manufacture_day=?,\r\n"
					+ "price =?,\r\n"
					+ "image_file=?\r\n"
					+ "where prod_no =? 	";			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productVO.getProdName());
			pstmt.setString(2, productVO.getProdDetail());
			pstmt.setString(3, productVO.getManuDate());
			pstmt.setInt(4, productVO.getPrice());
			pstmt.setString(5, productVO.getFileName());
			pstmt.setInt(6, productVO.getProdNo());
						
			int s = pstmt.executeUpdate();
			if(s==1) {
				System.out.println("Insert ����");
			} else {
				System.out.println("SQL Insert ����");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			this.close(con, pstmt);
			System.out.println("PDAO UpdateProduct end");
		}
	}
}
